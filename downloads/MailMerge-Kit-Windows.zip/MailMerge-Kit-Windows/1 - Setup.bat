@echo off
cd /d "%~dp0sender"
echo == Mail Merge Kit: setup ==
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Opening the download page...
  echo Install the LTS version, then double-click this file again.
  start "" https://nodejs.org/
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo Node.js %%v found. Installing, this takes a few seconds...
call npm install --no-fund --no-audit
if errorlevel 1 ( echo Install failed. & pause & exit /b 1 )
if not exist .env ( copy .env.example .env >nul & echo Created your settings file .env )
echo Opening your settings in Notepad. Fill them in and save.
start "" notepad .env
echo.
echo Setup done. Next: edit sender\contacts.csv and sender\template.html,
echo then double-click "2 - Preview.bat"
pause

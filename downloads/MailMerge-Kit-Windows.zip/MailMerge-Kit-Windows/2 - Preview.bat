@echo off
cd /d "%~dp0sender"
echo == Preview: nothing will be sent ==
node mailmerge.js --dry-run
if exist preview.html start "" preview.html
echo.
pause

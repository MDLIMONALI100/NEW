@echo off
cd /d "%~dp0sender"
if not exist .env copy .env.example .env >nul
start "" notepad .env

@echo off
cd /d "%~dp0sender"
echo == Send emails for real ==
echo This sends one email to every person in contacts.csv.
set /p ans=Type SEND and press Enter to continue: 
if /i not "%ans%"=="SEND" ( echo Cancelled. Nothing was sent. & pause & exit /b 0 )
node mailmerge.js
echo.
echo Keep this window open until you see Done.
pause

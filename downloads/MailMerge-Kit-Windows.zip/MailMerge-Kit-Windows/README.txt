MAIL MERGE KIT for Windows
==========================
Sends one personal email to each person in a list, from your own email account.

ONE-TIME SETUP
  1. Unzip the kit first (right-click the zip > Extract All). It won't work from inside the zip.
  2. Install Node.js (the LTS version) from https://nodejs.org with the default options.
  3. Double-click  "1 - Setup.bat"
     If Windows shows "Windows protected your PC": click More info > Run anyway.
  4. Notepad opens your settings. Fill them in (see below) and save.
     To change them later, double-click "Edit settings.bat"

YOUR SETTINGS (the .env file)
  SMTP_HOST   smtp.gmail.com for Gmail (or your email provider's SMTP server)
  SMTP_PORT   587
  SMTP_USER   your email address
  SMTP_PASS   an App Password, NOT your normal password
              Gmail: turn on 2-Step Verification, then Google Account > Security > App passwords
  FROM_NAME   the name people see
  SUBJECT     the subject line; {{name}} is replaced with each person's name
  CAMPAIGN    a name for this send, e.g. winter-sale
  Never share or upload the .env file. It holds your password.

EACH TIME YOU SEND
  1. sender/contacts.csv  - your list. First row must be: name,email,business
                            (open it in Excel, Numbers or any text editor)
  2. sender/template.html - your email. {{name}} and {{business}} are filled in per person.
  3. Preview first. Nothing is sent, and preview.html opens so you can see the email.
  4. Send. It asks you to type SEND. Keep the window open until it says Done.
     Addresses that fail are saved to sender/failed.txt.

OPTIONAL: OPEN AND CLICK TRACKING
  Tracking is OFF until you deploy your own tracker. You need a free Cloudflare account.
  In a terminal, inside the "tracker" folder:
    npx wrangler login
    npx wrangler kv namespace create TRACK      (paste the id into wrangler.toml)
    edit ALLOWED_HOSTS in wrangler.toml to your own website
    npx wrangler secret put STATS_KEY           (type a long random password)
    npx wrangler deploy                         (prints your tracker address)
  Then in .env set:
    TRACKER_URL=https://mail-tracker.YOUR-NAME.workers.dev
    TRACKED_HOSTS=yourwebsite.com,www.yourwebsite.com
  Dashboard: https://mail-tracker.YOUR-NAME.workers.dev/dashboard?key=YOUR_STATS_KEY
  With tracking on, the kit also writes sender/recipients.csv and a hidden .tracking-salt file.
  Keep both: choose recipients.csv on the dashboard to see names next to the codes.

GOOD TO KNOW
  - Only email people who agreed to hear from you, and keep the unsubscribe line.
  - A normal Gmail account can send about 500 emails a day.
  - Opens are approximate (Apple Mail and Gmail load images on their own). Clicks are reliable.

Made by Md Limon Ali - https://mdlimonali.com


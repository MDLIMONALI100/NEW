// mail-tracker: counts email opens (pixel) and link clicks (redirect).
// Bindings: TRACK (KV), STATS_KEY (secret), ALLOWED_HOSTS (comma list of hosts links may point to).

const PIXEL = Uint8Array.from(
  atob("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"),
  (c) => c.charCodeAt(0)
);

async function bump(env, key) {
  const n = parseInt((await env.TRACK.get(key)) || "0", 10) + 1;
  await env.TRACK.put(key, String(n));
}

// Per-recipient counter: stores {n: count, t: last time in ms}.
async function bumpWho(env, key) {
  let v = {};
  try { v = JSON.parse((await env.TRACK.get(key)) || "{}"); } catch {}
  await env.TRACK.put(key, JSON.stringify({ n: (v.n || 0) + 1, t: Date.now() }));
}

const DASHBOARD =`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Mail Tracker</title>
<style>
:root{--bg:#0e0e10;--card:#18181b;--line:#2a2a2f;--txt:#f4f4f5;--mut:#9a9aa3;--lime:#c6ff3d;--blue:#5b9dff}
@media(prefers-color-scheme:light){:root{--bg:#f6f6f4;--card:#fff;--line:#e3e3df;--txt:#111;--mut:#666;--lime:#4f8a00;--blue:#1f6fe0}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);font:15px/1.5 system-ui,sans-serif}
main{max-width:920px;margin:0 auto;padding:24px 16px 60px}
h1{font-size:22px;margin:0}h2{font-size:15px;margin:32px 0 12px;color:var(--mut);text-transform:uppercase;letter-spacing:.08em}
.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.sub{color:var(--mut);font-size:13px}
.totals{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px}
.big{font-size:32px;font-weight:700}.lbl{color:var(--mut);font-size:13px}
.camp{margin-bottom:12px}.camp h3{margin:0 0 10px;font-size:16px;word-break:break-all}
.row{display:grid;grid-template-columns:70px 1fr 56px;gap:10px;align-items:center;margin:6px 0;font-size:13px}
.bar{height:10px;border-radius:5px;background:var(--line);overflow:hidden}.bar i{display:block;height:100%}
.o i{background:var(--blue)}.c i{background:var(--lime)}.row b{text-align:right}
.rate{color:var(--mut);font-size:13px;margin-top:8px}
.empty{color:var(--mut);padding:24px;text-align:center}
label{display:block;font-size:13px;color:var(--mut);margin:10px 0 4px}
input{width:100%;padding:10px;border-radius:8px;border:1px solid var(--line);background:var(--bg);color:var(--txt);font:inherit}
textarea{width:100%;height:96px;padding:10px;border-radius:8px;border:1px solid var(--line);background:var(--bg);color:var(--txt);font:12px/1.4 ui-monospace,monospace}
button{margin-top:10px;padding:9px 14px;border:0;border-radius:8px;background:var(--lime);color:#111;font-weight:600;cursor:pointer}
@media(max-width:560px){.totals{grid-template-columns:1fr}}
</style></head><body><main>
<div class="top"><div><h1>Mail Tracker</h1><div class="sub" id="upd">Loading...</div></div><div><button id="ref" style="margin:0">Refresh</button></div></div>
<div class="totals">
<div class="card"><div class="big" id="to">0</div><div class="lbl">Total opens</div></div>
<div class="card"><div class="big" id="tc">0</div><div class="lbl">Total clicks</div></div>
<div class="card"><div class="big" id="tr">0%</div><div class="lbl">Click rate</div></div>
</div>
<h2>Campaigns</h2><div id="list"></div>
<h2>People</h2>
<div class="card"><div class="sub">Pick the recipients.csv file from your mail folder to see email addresses. It is read in your browser only and is never uploaded.</div>
<input type="file" id="csv" accept=".csv" style="margin-top:10px"><div id="ppl" style="margin-top:12px;overflow-x:auto"></div></div>
<h2>Link builder</h2>
<div class="card">
<label for="cid">Campaign name</label><input id="cid" value="my-first-campaign">
<label for="curl">Page the button should open</label><input id="curl" value="https://shop.example.com/">
<button id="gen">Make code</button>
<label for="out">Paste this into your email</label><textarea id="out" readonly></textarea>
</div>
</main>
<script>
var key=new URLSearchParams(location.search).get("key")||"";
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e}
function bar(cls,name,n,max){var r=el("div","row "+cls);r.appendChild(el("span","",name));var b=el("div","bar");var i=el("i");i.style.width=(max?Math.max(n/max*100,n?2:0):0)+"%";b.appendChild(i);r.appendChild(b);r.appendChild(el("b","",n));return r}
var people={},names={};
function renderPeople(){
  var box=document.getElementById("ppl");box.textContent="";
  var rows=Object.keys(people).map(function(k){return people[k]}).sort(function(a,b){return b.t-a.t});
  if(!rows.length){box.appendChild(el("div","sub","No per-person data yet. It starts with emails sent by the updated mail script."));return}
  var tb=el("table");tb.style.cssText="width:100%;border-collapse:collapse;font-size:13px";
  var hr=el("tr");["Person","Campaign","Opens","Clicks","Last activity"].forEach(function(h){var th=el("th","",h);th.style.cssText="text-align:left;padding:6px 8px;color:var(--mut);font-weight:500";hr.appendChild(th)});tb.appendChild(hr);
  rows.forEach(function(p){var tr=el("tr");[names[p.r]||p.r,p.c,p.o,p.cl,p.t?new Date(p.t).toLocaleString():""].forEach(function(v){var td=el("td","",v);td.style.cssText="padding:6px 8px;border-top:1px solid var(--line);word-break:break-all";tr.appendChild(td)});tb.appendChild(tr)});
  box.appendChild(tb);
}
document.getElementById("csv").onchange=function(e){var f=e.target.files[0];if(!f)return;var rd=new FileReader();
  rd.onload=function(){names={};rd.result.split(String.fromCharCode(10)).forEach(function(l){var p=l.trim().split(",");if(p.length>=2&&p[0]!=="hash")names[p[0]]=p[1]});renderPeople()};rd.readAsText(f)};
async function load(){
  var res=await fetch("/stats?key="+encodeURIComponent(key));
  var list=document.getElementById("list");list.textContent="";
  if(!res.ok){list.appendChild(el("div","empty","Could not load stats (wrong key?)"));return}
  var d=await res.json(),camps={};
  people={};
  Object.keys(d).forEach(function(k){if(k.indexOf("who:")!==0)return;var q=k.split(":"),ty=q.pop(),r=q.pop();q.shift();var c=q.join(":"),pk=c+":"+r;
    var p=people[pk]=people[pk]||{c:c,r:r,o:0,cl:0,t:0};if(ty==="open")p.o=d[k].n;if(ty==="click")p.cl=d[k].n;p.t=Math.max(p.t,d[k].t||0)});
  renderPeople();
  Object.keys(d).forEach(function(k){if(k.indexOf("who:")===0)return;var p=k.indexOf(":"),t=k.slice(0,p),id=k.slice(p+1);camps[id]=camps[id]||{o:0,c:0};if(t==="open")camps[id].o=d[k];if(t==="click")camps[id].c=d[k]});
  var ids=Object.keys(camps).sort(function(a,b){return camps[b].o+camps[b].c-camps[a].o-camps[a].c});
  var to=0,tc=0,max=1;ids.forEach(function(i){to+=camps[i].o;tc+=camps[i].c;max=Math.max(max,camps[i].o,camps[i].c)});
  document.getElementById("to").textContent=to;document.getElementById("tc").textContent=tc;
  document.getElementById("tr").textContent=(to?Math.round(tc/to*100):0)+"%";
  if(!ids.length)list.appendChild(el("div","card empty","No data yet. Send an email with the pixel and links below."));
  ids.forEach(function(i){var c=el("div","card camp");c.appendChild(el("h3","",i));
    c.appendChild(bar("o","Opens",camps[i].o,max));c.appendChild(bar("c","Clicks",camps[i].c,max));
    c.appendChild(el("div","rate","Click rate: "+(camps[i].o?Math.round(camps[i].c/camps[i].o*100):0)+"%"));list.appendChild(c)});
  document.getElementById("upd").textContent="Updated "+new Date().toLocaleTimeString();
}
document.getElementById("ref").onclick=load;
document.getElementById("gen").onclick=function(){
  var id=encodeURIComponent(document.getElementById("cid").value.trim()||"campaign"),u=encodeURIComponent(document.getElementById("curl").value.trim()),o=location.origin;
  document.getElementById("out").value='<a href="'+o+'/c?id='+id+'&u='+u+'">Shop now</a>\\n<img src="'+o+'/o?id='+id+'" width="1" height="1" alt="">';
};
document.getElementById("gen").onclick();load();setInterval(load,30000);
</script></body></html>`;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const id = (url.searchParams.get("id") || "none").slice(0, 64).replace(/:/g, "-");
    const who = (url.searchParams.get("r") || "").replace(/[^a-z0-9]/gi, "").slice(0, 24);

    if (url.pathname === "/") return new Response("ok");

    // Open tracking: <img src="https://.../o?id=campaign1">
    if (url.pathname === "/o") {
      ctx.waitUntil(bump(env, `open:${id}`));
      if (who) ctx.waitUntil(bumpWho(env, `who:${id}:${who}:open`));
      return new Response(PIXEL, {
        headers: { "content-type": "image/gif", "cache-control": "no-store" },
      });
    }

    // Click tracking: https://.../c?id=campaign1&u=https://shop.example.com/...
    if (url.pathname === "/c") {
      let target;
      try {
        target = new URL(url.searchParams.get("u"));
      } catch {
        return new Response("bad url", { status: 400 });
      }
      const allowed = (env.ALLOWED_HOSTS || "")
        .split(",")
        .map((h) => h.trim().toLowerCase())
        .filter(Boolean);
      if (!/^https?:$/.test(target.protocol) || !allowed.includes(target.hostname.toLowerCase())) {
        return new Response("host not allowed", { status: 403 });
      }
      ctx.waitUntil(bump(env, `click:${id}`));
      if (who) ctx.waitUntil(bumpWho(env, `who:${id}:${who}:click`));
      return Response.redirect(target.toString(), 302);
    }

    // Dashboard: GET /dashboard?key=SECRET (page itself reads /stats with the same key)
    if (url.pathname === "/dashboard") {
      const key = url.searchParams.get("key");
      if (!env.STATS_KEY || key !== env.STATS_KEY) return new Response("forbidden", { status: 403 });
      return new Response(DASHBOARD, {
        headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "referrer-policy": "no-referrer" },
      });
    }

    // Stats: GET /stats?key=SECRET (or header x-stats-key)
    if (url.pathname === "/stats") {
      const key = url.searchParams.get("key") || request.headers.get("x-stats-key");
      if (!env.STATS_KEY || key !== env.STATS_KEY) return new Response("forbidden", { status: 403 });
      const out = {};
      let cursor;
      do {
        const list = await env.TRACK.list({ cursor });
        for (const k of list.keys) {
          const v = (await env.TRACK.get(k.name)) || "0";
          out[k.name] = k.name.startsWith("who:") ? JSON.parse(v) : parseInt(v, 10);
        }
        cursor = list.list_complete ? undefined : list.cursor;
      } while (cursor);
      return Response.json(out);
    }

    return new Response("not found", { status: 404 });
  },
};

#!/usr/bin/env node
'use strict';

/**
 * Lightweight CLI mail merge.
 *   contacts.csv  -> email, name, business
 *   template.html -> HTML body with {{name}} / {{business}} placeholders
 *   .env          -> SMTP settings
 *
 * Usage:
 *   node mailmerge.js              # send for real
 *   node mailmerge.js --dry-run    # render and log, send nothing
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const DRY_RUN = process.argv.includes('--dry-run');
const ROOT = process.cwd();
let CAMPAIGN = 'mail';

// ---------- tiny helpers (no external deps) ----------

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
}

// RFC 4180-style CSV parser: quoted fields, escaped quotes, CRLF, BOM.
function parseCsv(text) {
  text = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field); field = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      rows.push(row); row = [];
    } else {
      field += c;
    }
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }

  const nonEmpty = rows.filter((r) => r.some((cell) => cell.trim() !== ''));
  if (!nonEmpty.length) return [];
  const headers = nonEmpty[0].map((h) => h.trim().toLowerCase());
  return nonEmpty.slice(1).map((r) => {
    const obj = {};
    headers.forEach((h, idx) => { obj[h] = (r[idx] || '').trim(); });
    return obj;
  });
}

const escapeHtml = (s) =>
  String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

// Replace {{key}} (whitespace tolerant, case-insensitive). Unknown keys become empty.
function render(template, data, { html = true } = {}) {
  return template.replace(/\{\{\s*([\w-]+)\s*\}\}/g, (_, key) => {
    const val = data[key.toLowerCase()] ?? '';
    return html ? escapeHtml(val) : val;
  });
}

const htmlToText = (html) =>
  html
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\n{3,}/g, '\n\n')
    .trim();

// ---------- open/click tracking (optional, needs your own tracker worker) ----------
// Set TRACKER_URL and TRACKED_HOSTS in .env to turn tracking on. Leave TRACKER_URL empty to send without tracking.
let TRACKER = '';
let TRACKED_HOSTS = [];
function isTracked(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) && TRACKED_HOSTS.includes(u.hostname.toLowerCase());
  } catch { return false; }
}

// Private per-person code: keyed hash of the address, so Cloudflare never sees the email.
// The key lives in .tracking-salt (created once, keep it). recipients.csv maps code -> email.
function recipientCode(email) {
  const saltFile = path.join(ROOT, '.tracking-salt');
  if (!fs.existsSync(saltFile)) fs.writeFileSync(saltFile, crypto.randomBytes(16).toString('hex'), { mode: 0o600 });
  const salt = fs.readFileSync(saltFile, 'utf8').trim();
  return crypto.createHmac('sha256', salt).update(email).digest('hex').slice(0, 10);
}

// Send shop links through the tracker and add the invisible open pixel.
function addTracking(html, campaign, rid) {
  if (!TRACKER) return html;
  const id = encodeURIComponent(campaign);
  const who = rid ? `&amp;r=${rid}` : '';
  html = html.replace(/href="([^"]+)"/gi, (m, url) =>
    isTracked(url) ? `href="${TRACKER}/c?id=${id}${who}&amp;u=${encodeURIComponent(url)}"` : m
  );
  const pixel = `<img src="${TRACKER}/o?id=${id}${who}" width="1" height="1" alt="" style="display:block;border:0;">`;
  return /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${pixel}</body>`) : html + pixel;
}

const oneLine =(s) => String(s).replace(/[\r\n]+/g, ' ').trim(); // header-injection guard
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function fail(msg) {
  console.error(`Error: ${msg}`);
  process.exit(1);
}

// ---------- main ----------

async function main() {
  loadEnv(path.join(ROOT, '.env'));
  TRACKER = (process.env.TRACKER_URL || '').trim().replace(/\/+$/, '');
  TRACKED_HOSTS = (process.env.TRACKED_HOSTS || '').split(',').map((h) => h.trim().toLowerCase()).filter(Boolean);
  if (TRACKER && !/^https:\/\//.test(TRACKER)) fail('TRACKER_URL must start with https://');

  const {
    SMTP_HOST,
    SMTP_PORT = '587',
    SMTP_SECURE,
    SMTP_USER,
    SMTP_PASS,
    FROM_NAME = '',
    FROM_EMAIL,
    SUBJECT = 'Hello {{name}}',
    DELAY_MS = '2000',
  } = process.env;

  const missing = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS'].filter((k) => !process.env[k]);
  if (missing.length && !DRY_RUN) fail(`Missing in .env: ${missing.join(', ')}`);

  const csvPath = path.join(ROOT, 'contacts.csv');
  const tplPath = path.join(ROOT, 'template.html');
  if (!fs.existsSync(csvPath)) fail('contacts.csv not found in the current folder.');
  if (!fs.existsSync(tplPath)) fail('template.html not found in the current folder.');

  const template = fs.readFileSync(tplPath, 'utf8');
  const all = parseCsv(fs.readFileSync(csvPath, 'utf8'));
  if (!all.length) fail('contacts.csv has no data rows.');
  if (!('email' in all[0])) fail('contacts.csv needs an "email" column (email, name, business).');

  // Validate + de-duplicate
  const seen = new Set();
  const contacts = [];
  let skipped = 0;
  for (const c of all) {
    const email = (c.email || '').toLowerCase();
    if (!EMAIL_RE.test(email)) { console.warn(`Skipping invalid email: "${c.email}"`); skipped++; continue; }
    if (seen.has(email)) { console.warn(`Skipping duplicate: ${email}`); skipped++; continue; }
    seen.add(email);
    contacts.push({ ...c, email });
  }
  if (!contacts.length) fail('No valid recipients found.');

  // Campaign name shown on the dashboard. Set CAMPAIGN in .env, or it defaults to today's date.
  CAMPAIGN = (process.env.CAMPAIGN || `mail-${new Date().toISOString().slice(0, 10)}`).trim();
  console.log(TRACKER ? `Tracking campaign: ${CAMPAIGN}` : 'Tracking is off (no TRACKER_URL in .env).');

  const delay = Math.max(0, parseInt(DELAY_MS, 10) || 2000);
  const port = parseInt(SMTP_PORT, 10);
  const secure = SMTP_SECURE ? SMTP_SECURE.toLowerCase() === 'true' : port === 465;
  const fromAddr = FROM_EMAIL || SMTP_USER;
  const from = FROM_NAME ? `"${oneLine(FROM_NAME).replace(/"/g, '')}" <${fromAddr}>` : fromAddr;

  let transporter = null;
  if (!DRY_RUN) {
    transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port,
      secure, // true = implicit TLS (465); false = STARTTLS upgrade (587)
      requireTLS: !secure, // refuse to send in plaintext on STARTTLS ports
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
    process.stdout.write('Verifying SMTP connection... ');
    try {
      await transporter.verify();
      console.log('OK');
    } catch (err) {
      console.log('FAILED');
      fail(err.message);
    }
  }

  const total = contacts.length;
  console.log(
    `${DRY_RUN ? '[DRY RUN] ' : ''}${total} recipient(s)` +
      `${skipped ? `, ${skipped} skipped` : ''}, ${delay / 1000}s delay between sends.\n`
  );

  const failed = [];
  let sent = 0;

  for (let i = 0; i < total; i++) {
    const c = contacts[i];
    const tag = `[${i + 1}/${total}]`;
    const rid = TRACKER ? recipientCode(c.email) : '';
    if (TRACKER && !DRY_RUN) fs.appendFileSync(path.join(ROOT, 'recipients.csv'), `${rid},${c.email},${CAMPAIGN}\n`);
    const html = addTracking(render(template, c), CAMPAIGN, rid);
    if (DRY_RUN && i === 0) fs.writeFileSync(path.join(ROOT, 'preview.html'), html);

    try {
      if (DRY_RUN) {
        console.log(`${tag} Would send to ${c.email} (subject: "${oneLine(render(SUBJECT, c, { html: false }))}")`);
      } else {
        await transporter.sendMail({
          from,
          to: c.email,
          subject: oneLine(render(SUBJECT, c, { html: false })),
          html,
          text: htmlToText(html),
        });
        console.log(`${tag} Sent to ${c.email}`);
      }
      sent++;
    } catch (err) {
      console.error(`${tag} FAILED for ${c.email}: ${err.message}`);
      failed.push(c.email);
    }

    if (i < total - 1) await sleep(delay); // rate-limit pause between sends
  }

  console.log(`\nDone. ${DRY_RUN ? 'Rendered' : 'Sent'}: ${sent}, failed: ${failed.length}.`);
  if (failed.length) {
    fs.writeFileSync(path.join(ROOT, 'failed.txt'), failed.join('\n') + '\n');
    console.log('Failed addresses saved to failed.txt');
    process.exitCode = 1;
  }
  if (transporter) transporter.close();
}

process.on('SIGINT', () => {
  console.log('\nInterrupted. Stopping.');
  process.exit(130);
});

main().catch((err) => fail(err.message));

#!/bin/bash
cd "$(dirname "$0")/sender" || exit 1
echo "== Send emails for real =="
echo "This sends one email to every person in contacts.csv."
read -r -p "Type SEND and press Enter to continue: " ans
if [ "$ans" != "SEND" ]; then echo "Cancelled. Nothing was sent."; read -n 1 -s -r -p "Press any key to close."; exit 0; fi
node mailmerge.js
echo; echo "Keep this window open until you see Done."
read -n 1 -s -r -p "Press any key to close."

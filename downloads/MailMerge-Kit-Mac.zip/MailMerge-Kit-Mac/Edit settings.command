#!/bin/bash
cd "$(dirname "$0")/sender" || exit 1
[ -f .env ] || cp .env.example .env
open -e .env

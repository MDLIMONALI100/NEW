#!/bin/bash
cd "$(dirname "$0")/sender" || exit 1
echo "== Preview: nothing will be sent =="
node mailmerge.js --dry-run
[ -f preview.html ] && open preview.html
echo; read -n 1 -s -r -p "Press any key to close."

#!/bin/bash
cd "$(dirname "$0")/sender" || exit 1
echo "== Mail Merge Kit: setup =="
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Opening the download page..."
  echo "Install the LTS version, then double-click this file again."
  open "https://nodejs.org/"
  read -n 1 -s -r -p "Press any key to close."; exit 1
fi
echo "Node.js $(node -v) found. Installing (this takes a few seconds)..."
npm install --no-fund --no-audit || { read -n 1 -s -r -p "Install failed. Press any key to close."; exit 1; }
if [ ! -f .env ]; then cp .env.example .env; echo "Created your settings file (.env)."; fi
echo "Opening your settings in TextEdit. Fill them in and save."
open -e .env
echo; echo "Setup done. Next: edit sender/contacts.csv and sender/template.html,"
echo "then double-click  2 - Preview.command"
read -n 1 -s -r -p "Press any key to close."
